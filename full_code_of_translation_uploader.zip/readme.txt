=== Translation Uploader ===
Contributors: Md. Shamim Islam
Tags: file upload, word count, translation
Requires at least: 5.5
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later
